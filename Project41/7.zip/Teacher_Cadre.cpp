#include "Teacher_Cadre.h"


void Teacher_Cadre::show()
{
	Teacher::display();
	cout << "ְ��" << Cadre::post << " н�꣺" << wages;
}